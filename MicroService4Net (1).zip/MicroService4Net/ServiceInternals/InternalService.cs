﻿using System;
using System.Configuration;
using System.ServiceProcess;
using System.Timers;

namespace TNT.SERVER_MASTER.ServiceInternals
{
    public class InternalService : ServiceBase
    {
        internal static event Action OsStarted;
        internal static event Action OsStopped;
        private Timer timer = null;

        public InternalService()
        {
            try
            {
                //Test();
                timer = new Timer();
                this.timer.Interval = int.Parse(ConfigurationManager.AppSettings["Interval"]);
                this.timer.Elapsed += new System.Timers.ElapsedEventHandler(this.timer_Tick);
            }
            catch (Exception ex)
            {
                //LogEventError.LogEvent(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                LogEventError.Log(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                timer.Enabled = false;
                timer.Stop();
                if (Setting.SERVICE_REQUEST_INFO != null)
                {
                    switch (Setting.SERVICE_REQUEST_INFO.SERVICE_TYPE.ToUpper())
                    {
                        case Constant.WINDOWS_SERVICE:
                            ServiceController service = new ServiceController(Setting.SERVICE_REQUEST_INFO.SERVICE_NAME);
                            switch (Setting.SERVICE_REQUEST_INFO.ACTION_REQUEST.ToUpper())
                            {
                                case Constant.STOP:
                                    if ((service.Status.Equals(ServiceControllerStatus.Running)) || (service.Status.Equals(ServiceControllerStatus.StartPending)))
                                    {
                                        service.Stop();
                                        LogEventError.Log(DateTime.Now.ToString() + ":" + Setting.SERVICE_REQUEST_INFO.SERVICE_NAME + " : STOP");
                                    }
                                    break;
                                case Constant.START:
                                    if ((service.Status.Equals(ServiceControllerStatus.Stopped)) || (service.Status.Equals(ServiceControllerStatus.StopPending)))
                                    {
                                        service.Start();
                                        LogEventError.Log(DateTime.Now.ToString() + ":" + Setting.SERVICE_REQUEST_INFO.SERVICE_NAME + " : START");
                                    }
                                    break;
                                case Constant.RESTART:
                                    if ((service.Status.Equals(ServiceControllerStatus.Running)) || (service.Status.Equals(ServiceControllerStatus.StartPending)))
                                    {
                                        service.Stop();
                                    }
                                    service.WaitForStatus(ServiceControllerStatus.Stopped);
                                    service.Start();
                                    service.WaitForStatus(ServiceControllerStatus.Running);
                                    break;
                                default:
                                    throw new Exception("is not a valid!");
                            }
                            break;
                        case Constant.IIS_SERVICE:
                            break;
                        default:
                            throw new Exception(" is not a valid!");
                    }
                   

                }

                //var infoRequest = Setting.SERVICE_REQUEST_INFO;
                //ServiceController service = new ServiceController("memcached");
                //if ((service.Status.Equals(ServiceControllerStatus.Stopped)) || (service.Status.Equals(ServiceControllerStatus.StopPending)))
                //{
                //    service.Start();
                //    LogEventError.Log("memcached Start----------------" + DateTime.Now.ToString());
                //}
                //else
                //{
                //    service.Stop();
                //    LogEventError.Log("memcached Stop----------------" + DateTime.Now.ToString());
                //}
                LogEventError.Log("----------------" + DateTime.Now.ToString());
                timer.Enabled = true;
                timer.Start();

            }
            catch (Exception ex)
            {
                LogEventError.Log(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                timer.Enabled = true;
                timer.Start();
            }
        }
        protected override void OnStart(string[] args)
        {
            timer.Enabled = true;
            timer.Start();
            LogEventError.Log("Service OnStart successfully" + "[" + DateTime.Now.ToString() + "]");
            OsStarted.Invoke();
        }

        protected override void OnStop()
        {
            timer.Enabled = false;
            timer.Stop();
            LogEventError.Log("Service OnStop successfully" + "[" + DateTime.Now.ToString() + "]");
            OsStopped.Invoke();
        }


    }
}
