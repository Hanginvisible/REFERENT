﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace TNT.SERVER_MASTER
{
    public class SECONDARY_INFO
    {
        [DataMember]
        [DisplayName("SERVER_NAME")]
        public string SERVER_NAME { get; set; }
        [DataMember]
        [DisplayName("IP")]
        public string IP { get; set; }

        [DataMember]
        [DisplayName("LIST_WIN_SERVICE")]
        public List<WINSERVICE_INFO> LIST_WIN_SERVICE { get; set; }

        [DataMember]
        [DisplayName("LIST_WEB_APP")]
        public List<WEB_APP_INFO> LIST_WEB_APP { get; set; }

        public SECONDARY_INFO()
        {
            SERVER_NAME = string.Empty;
            IP = string.Empty;
            LIST_WIN_SERVICE = null;
            LIST_WEB_APP = null;

        }
    }
}
