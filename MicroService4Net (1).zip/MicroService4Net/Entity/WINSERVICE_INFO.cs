﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace TNT.SERVER_MASTER
{
    public class WINSERVICE_INFO
    {
        [DataMember]
        [DisplayName("SERVICE_NAME")]
        public string SERVICE_NAME { get; set; }
        [DataMember]
        [DisplayName("DESCRIPTION")]
        public string DESCRIPTION { get; set; }       

        [DataMember]
        [DisplayName("STATUS")]
        public string STATUS { get; set; }
        public WINSERVICE_INFO()
        {
            SERVICE_NAME = string.Empty;
            DESCRIPTION = string.Empty;            
            STATUS = string.Empty;

        }
    }
}
