﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace TNT.SERVER_MASTER
{
    [Serializable]
    [DataContract]
    public class SERVICE_REQUEST_INFO
    {

        [DataMember]
        [DisplayName("SERVICE_NAME")]
        public string SERVICE_NAME { get; set; }
        [DataMember]
        [DisplayName("ACTION_REQUEST")]
        public string ACTION_REQUEST { get; set; }

        [DataMember]
        [DisplayName("SERVICE_TYPE")]
        public string SERVICE_TYPE { get; set; }

        public SERVICE_REQUEST_INFO()
        {
            SERVICE_NAME = string.Empty;
            ACTION_REQUEST = string.Empty;
            SERVICE_TYPE = string.Empty;

        }
    }
}
