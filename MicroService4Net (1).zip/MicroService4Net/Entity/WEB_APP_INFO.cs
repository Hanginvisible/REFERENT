﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace TNT.SERVER_MASTER
{
    public class WEB_APP_INFO
    {
        [DataMember]
        [DisplayName("WEB_APP_NAME")]
        public string WEB_APP_NAME { get; set; }
        [DataMember]
        [DisplayName("POOL_NAME")]
        public string POOL_NAME { get; set; }

        [DataMember]
        [DisplayName("PHYSICAL_PATH")]
        public string PHYSICAL_PATH { get; set; }

        [DataMember]
        [DisplayName("STATUS")]
        public string STATUS { get; set; }
        public WEB_APP_INFO()
        {
            WEB_APP_NAME = string.Empty;
            POOL_NAME = string.Empty;
            PHYSICAL_PATH = string.Empty;
            STATUS = string.Empty;

        }
    }
}
