﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TNT.SERVER_MASTER
{
    public class LogEventError
    {
        /// <summary>
        /// Log ghi lại error.
        /// </summary>
        /// <param name="fnName">Tên hàm Phát sinh lỗi</param>
        /// <param name="ex">Exception khi xảy ra lỗi</param>
        public static void Log(string fnName, Exception ex)
        {
            string message = string.Empty;
            //message += Environment.NewLine + "Product name :" + "";
            //message += Environment.NewLine + "Version :" + "";
            message += Environment.NewLine + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + ":" + fnName;
            message += Environment.NewLine + "Message :" + ex.Message;
            message += Environment.NewLine + "StackTrace : " + ex.StackTrace;
            DateTime date = DateTime.Now;
            StreamWriter writer = null;
            string fileName = date.ToString("yyyy-MM-dd") + ".log";
            if (!System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Log"))
            {
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Log");
            }
            
            string Source = Path.Combine(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Log", fileName);

            try
            {
                writer = new StreamWriter(Source, true);
                writer.WriteLine(message);
            }
            catch
            {
            }
            finally
            {
                if (writer != null)
                {
                    writer.Dispose();
                    writer.Close();
                }
            }

        }

        public static void Log(string message)
        {

            DateTime date = DateTime.Now;
            StreamWriter writer = null;
            string fileName = date.ToString("yyyy-MM-dd") + ".log";           
            if (!System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Log"))
            {
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Log");
            }
            string Source = Path.Combine(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Log", fileName);

            try
            {
                writer = new StreamWriter(Source, true);
                writer.WriteLine(message);
            }
            catch
            {
            }
            finally
            {
                if (writer != null)
                {
                    writer.Dispose();
                    writer.Close();
                }
            }

        }
    }
}
