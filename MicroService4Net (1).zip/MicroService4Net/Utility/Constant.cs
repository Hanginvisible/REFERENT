﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TNT.SERVER_MASTER
{
    public class Constant
    {
        public const string STOP = "STOP";
        public const string START = "START";
        public const string RESTART = "RESTART";
        public const string WINDOWS_SERVICE = "WINDOWS_SERVICE";
        public const string IIS_SERVICE = "IIS_SERVICE";
        public const string WEB_APP = "WEB_APP";
        public const string APPLICATION = "APPLICATION";

        public const string RETURN_CODE_SUCCESS = "1";
        public const string RETURN_CODE_ERROR = "-1";
        public const string RETURN_CODE_NOT_FOUND = "0";

        public const string MESSAGE_AUT_ERROR = "Xác thực không thành công ! ";
        public const string MESSAGE_ERROR = "Thực hiện không thành công ! ";
        public const string MESSAGE_NOT_FOUND = "Không tìm thấy ! ";
        public const string MESSAGE_ERROR_ADD = "Thêm mới dữ liệu không thành công ! ";
        public const string MESSAGE_ERROR_DELETE = "Xóa dữ liệu không thành công ! ";
        public const string MESSAGE_ERROR_UPDATE = "Cập nhật dữ liệu không thành công ! ";
        public const string MESSAGE_ERROR_EXIST = "Nội dung đã tồn tại trong hệ thống ! ";
        public const string MESSAGE_AUT_SUCCESS = "Xác thực không thành công ! ";
        public const string MESSAGE_SUCCESS = "Thực hiện thành công ! ";
        public const string MESSAGE_SUCCESS_ADD = "Thêm mới dữ liệu thành công ! ";
        public const string MESSAGE_SUCCESS_UPDATE = "Cập nhật dữ liệu thành công ! ";
        public const string MESSAGE_SUCCESS_DELETE = "Xóa dữ liệu thành công ! ";
    }
}
