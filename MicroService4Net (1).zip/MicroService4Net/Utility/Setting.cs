﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TNT.SERVER_MASTER
{
    public class Setting
    {
        public static SERVICE_REQUEST_INFO SERVICE_REQUEST_INFO = null;
        //public static string EHR_PORTAL
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(_EHR_PORTAL))
        //        {
        //            _EHR_PORTAL = ConfigurationManager.AppSettings[Constant.EHR_PORTAL];
        //        }
        //        return _EHR_PORTAL;
        //    }
        //}
    }
}
