﻿using TNT.SERVER_MASTER.ServiceInternals;

namespace TNT.SERVER_MASTER.WEB_API
{
    public class MicroServiceInstaller : ProjectInstaller { }
    public class MicroServiceService : InternalService { }
}
