﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.ServiceProcess;
using System.Web.Http;
using System.Web.Http.Cors;

namespace TNT.SERVER_MASTER.WEB_API.Controllers
{
    [EnableCors("*", "*", "*")]
    public class ExampleController : ApiController
    {
        private static readonly string ExampleField;

        static ExampleController()
        {
            ExampleField = "Example";
        }

        [Route("Example/{serviceID}")]
        public Response GetExample(string serviceID)
        {
            Response response = new Response();
            response.ResultCode = "";
            response.Message = "aaaaaaaaaaaa";
            response.ReturnValue = serviceID;
            return response;
        }
        [Route("WebApi/SendInfo")]
        public Response SERVICE_REQUEST_INFO(SERVICE_REQUEST_INFO serviceRequestInfo)
        {
            // Validate and add book to database (not shown)

            //var response = Request.CreateResponse(HttpStatusCode.Created);

            //// Generate a link to the new book and set the Location header in the response.
            //string uri = Url.Link("GetBookById", new { id = book.BookId });            
            //response.Headers.Location = new Uri(uri);
            try
            {
                Setting.SERVICE_REQUEST_INFO = serviceRequestInfo;
                return new Response
                {
                    ResultCode = Constant.RETURN_CODE_SUCCESS,
                    Message = Constant.MESSAGE_SUCCESS,
                    ReturnValue = serviceRequestInfo.ACTION_REQUEST
                };

            }
            catch (Exception ex)
            {
                return new Response
                {
                    ResultCode = Constant.RETURN_CODE_ERROR,
                    Message = Constant.MESSAGE_ERROR,
                    ReturnValue = null
                };
                
            }

        }

        [Route("Example/PostResponse2")]
        public Response2 PostResponse2(Response2 response)
        {
            // Validate and add book to database (not shown)

            //var response = Request.CreateResponse(HttpStatusCode.Created);

            //// Generate a link to the new book and set the Location header in the response.
            //string uri = Url.Link("GetBookById", new { id = book.BookId });
            //response.Headers.Location = new Uri(uri);
            response.ResultCode = "1";
            response.Message = response.Message + "_" + DateTime.Now.ToString("yyyy-MM-dd : HH:mm:ss");
            response.ReturnValue = "10";
            return response;

        }
    }

    [Serializable]
    [DataContract]
    public class Response
    {
        [DataMember]
        [DisplayName("ResultCode")]
        public string ResultCode { get; set; }

        [DataMember]
        [DisplayName("Message")]
        public string Message { get; set; }

        [DataMember]
        [DisplayName("ReturnValue")]
        public string ReturnValue { get; set; }

        public Response()
        {
            ResultCode = string.Empty;
            Message = string.Empty;
            ReturnValue = string.Empty;
        }
    }

    [Serializable]
    [DataContract]
    public class Response2
    {
        [DataMember]
        [DisplayName("ResultCode")]
        public string ResultCode { get; set; }

        [DataMember]
        [DisplayName("Message")]
        public string Message { get; set; }

        [DataMember]
        [DisplayName("ReturnValue")]
        public string ReturnValue { get; set; }

        public Response2()
        {
            ResultCode = string.Empty;
            Message = string.Empty;
            ReturnValue = string.Empty;
        }
    }
}
