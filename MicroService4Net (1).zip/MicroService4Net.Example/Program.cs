﻿namespace TNT.SERVER_MASTER.WEB_API
{
    class Program
    {
        static void Main(string[] args)
        {
            var microService = new MicroService();
            microService.Run(args);
        }
    }
}
